"""
strategicc/validation/correction.py  —  v3.16
--------------------------------------------------
Auto-correction of Transition Multipliers, given a hindcast run's observed
vs. simulated divergence, broken down by pathway (attribute_extent_drift()).

Two methods, selected via `method=`:

  "scaling"  (default) — for each flagged pathway, compute a single ratio:
             observed_rate / simulated_rate over the hindcast window, then
             rescale that pathway's Transition Multiplier by that ratio.
             Closed-form, no re-running the engine.

             IMPORTANT: DistributionMin/Max in TransitionMultipliers.csv
             are only actually used by the engine when DistributionType
             == "Uniform" (see core/multipliers.py). For a group whose
             DistributionType is a NAMED reference (e.g.
             calibration.temporal's empirical output), the engine ignores
             DistributionMin/Max entirely and samples from Distributions.csv
             instead. Scaling only DistributionMin/Max for such a group is
             therefore a no-op at simulation time. This module detects
             which case applies per group and scales the right file --
             Distributions.csv's Value column for named distributions,
             DistributionMin/Max for literal "Uniform" rows.

  "optimize" — per flagged group, a bounded 1-D search (scipy
             minimize_scalar) over a scale factor, using cheap trial
             hindcast re-runs (hindcast_run(..., lightweight=True)) as the
             objective function. Design parameters:
               - bounds: same as "scaling", (0.01, 100.0) by default
               - stopping rule: fixed max iterations (maxiter passed to
                 the bounded search)
               - re-run budget: max_reruns trial re-runs per group
                 (default 8) -- the binding constraint; maxiter is capped
                 to it so the search can't exceed the affordable re-run
                 budget even if the bounded method's internal iteration
                 count would otherwise run more evaluations.

Adjustment target
------------------
Corrections are applied to Transition Multipliers, NOT to the calibrated
base Transitions.csv probabilities -- the empirical baseline stays
untouched; only the temporal-variability layer on top of it is rescaled.

NOTE on scope vs. strategicc.calibration.transitions.normalize_transition_rates():
that function is the one that DOES touch the baseline -- it rescales
Transitions.csv itself, upstream at calibration time, to correct for
probability mass lost to unmapped pathways excluded by group_map. It runs
before correct_multipliers() ever sees the pipeline and is independent of
it; "the empirical baseline stays untouched" above is a statement about
what THIS module does, not a whole-pipeline guarantee.

v3.16 -- group-level, with the unit fix retained
--------------------------------------------------
v3.14 redesigned compute_pathway_rate_ratios() to operate at the
(from_class, to_class) PAIR level instead of pooling every pair sharing a
TransitionTypeId "group" together. That pair-level output is more detail
than this project wants by default: if a caller wants per-pair rates,
they can compute that themselves from trans_df / area_df directly rather
than have it forced on every caller.

This version reverts to v3.13's GROUP-level pooling (one row per
TransitionTypeId group, matching how Transitions.csv and
TransitionMultipliers.csv are keyed), while keeping the one part of the
v3.14 redesign that was a genuine bug fix rather than a detail-level
choice: the simulated-side denominator (mean_pool) is converted from
area_df's hectare column to a pixel count via px_area_ha BEFORE dividing,
so it's comparable to the numerator (mean_n_transitioned), which is
always a genuine pixel count. Pre-v3.14, every simulated_rate (and
therefore every ratio) was off by a constant factor of 1/px_area_ha.
px_area_ha is therefore a required parameter here, same as v3.14 -- this
is not optional or reverted, only the pair-vs-group grouping is.

The v3.14 weighting-mismatch discussion (observed_rate unweighted across
a group's pairs vs. simulated_rate pool-weighted across those same pairs)
still applies to any group spanning more than one (from_class, to_class)
pair: pooling by group means the pooled ratio doesn't represent any one
pathway's individual performance. If that matters for a given group, the
recommended fix is still to split it into separately-calibrated
TransitionTypeId rows at the group_map/calibration stage, or to compute
pair-level rates directly rather than relying on this function.
"""

from __future__ import annotations
from pathlib import Path

import numpy as np
import pandas as pd

from strategicc.io.csv_loader import _strip_type_suffix

_LITERAL_DISTRIBUTIONS = {"uniform"}


# ─────────────────────────────────────────────────────────────────────────────
# Pathway rate ratios (observed vs. simulated), from a hindcast run
# ─────────────────────────────────────────────────────────────────────────────

def compute_pathway_rate_ratios(
    trans_df:              pd.DataFrame,
    area_df:                pd.DataFrame,
    transitions_csv_path:   str | Path,
    px_area_ha:             float,
    n_timesteps:            int | None = None,
) -> pd.DataFrame:
    """
    Mean annual transition probability per group from a simulated hindcast
    run, compared against the calibrated (observed) rate for that group in
    Transitions.csv.

    Grouping (v3.16 -- reverted to v3.13's convention)
    -----------------------------------------------------
    Rates are pooled at the TransitionTypeId GROUP level -- every
    (from_class, to_class) pair sharing a group is combined into one row
    -- matching how Transitions.csv and TransitionMultipliers.csv are
    keyed, and how correct_multipliers() applies a single scale per group.
    (v3.14 briefly switched this to pair-level output; that level of
    detail wasn't wanted by default here and has been reverted. Compute
    pair-level rates directly from trans_df / area_df if you need them.)

    Simulated rate calculation
    ------------------------------------------------------
    Mirrors how the OBSERVED side already computes rates in
    calibration.transitions.compute_yearly_transition_counts() /
    compute_transition_rates(): for each YEAR separately, the eligible
    source-class pool is taken from THAT year's actual area (not a single
    pool measured once at the start and held constant), giving that
    year's real probability; the per-year probabilities are then averaged
    across years -- an unweighted mean, same convention
    compute_transition_rates() uses on the observed side. Since the
    simulation has multiple stochastic iterations (unlike the single
    historical record), each year's rate is itself an average across
    iterations before being averaged across years.

    Unit fix (kept from v3.14)
    ------------------------------------------------------
    area_df's pool is denominated in hectares; the numerator
    (mean_n_transitioned) is always a genuine pixel count. This function
    converts the hectare pool to a pixel count via px_area_ha BEFORE
    dividing, so numerator and denominator are in the same units.
    Pre-v3.14, this conversion was missing and every simulated_rate (and
    therefore every ratio) was off by a constant factor of 1/px_area_ha.
    px_area_ha is a REQUIRED parameter for this reason -- it is not an
    optional, revertible part of this redesign.

    Parameters
    ----------
    trans_df    : concatenated transition_log.csv from the hindcast run
                  (iteration, year, row, col, from_class, to_class, group)
    area_df     : concatenated area_table.csv from the hindcast run
                  (iteration, year, class_id, class_name, area_{unit} in
                  hectares -- an "area_" prefixed column)
    transitions_csv_path : path to the calibrated Transitions.csv
                  (StateClassIdSource, StateClassIdDest, TransitionTypeId,
                  Probability) -- observed rates, one row per group
                  (TransitionTypeId IS the group column here).
    px_area_ha  : pixel area in hectares (e.g. engine.px_area_ha) --
                  REQUIRED to convert area_df's hectare pool into a pixel
                  count comparable to trans_df's pixel-count transition
                  totals (see "Unit fix" above).
    n_timesteps : unused, kept only for call-site backward compatibility;
                  rates are computed per-year regardless of this value.

    Returns
    -------
    DataFrame: group, observed_rate, simulated_rate, ratio, n_years_used
    (ratio = observed_rate / simulated_rate; NaN where simulated_rate is 0
    or no valid year had a positive pool; n_years_used reports how many
    of the window's years actually contributed a rate, so a ratio backed
    by very few years can be treated with appropriate caution)
    """
    if trans_df.empty:
        return pd.DataFrame(
            columns=["group", "observed_rate", "simulated_rate", "ratio", "n_years_used"]
        )

    acol = next((c for c in area_df.columns if c.startswith("area_")), None)
    if acol is None:
        raise ValueError(f"area_df has no area_* column. Got: {list(area_df.columns)}")

    obs_df = pd.read_csv(transitions_csv_path)
    obs_df["group"] = obs_df["TransitionTypeId"].apply(_strip_type_suffix)
    observed_rates = obs_df.groupby("group")["Probability"].mean().to_dict()

    all_iterations = sorted(trans_df["iteration"].unique())

    rows = []
    for group, grp_trans in trans_df.groupby("group"):
        source_classes = grp_trans["from_class"].unique().tolist()

        yearly_rates = []
        for year, grp_year in grp_trans.groupby("year"):
            # Cells transitioned this year, averaged across iterations
            # (an iteration with zero transitions this year has no rows
            # in grp_year at all -- reindex so it correctly counts as 0,
            # not simply absent from the average).
            n_by_iter = (
                grp_year.groupby("iteration").size()
                .reindex(all_iterations, fill_value=0)
            )
            mean_n_transitioned = n_by_iter.mean()

            # This YEAR's actual source-class pool, averaged across
            # iterations (real per-year area, not a single value from
            # year 1 reused for the whole window).
            year_area = area_df[
                (area_df["year"] == year) & (area_df["class_name"].isin(source_classes))
            ]
            pool_by_iter = year_area.groupby("iteration")[acol].sum()
            if pool_by_iter.empty:
                continue
            mean_pool_ha = pool_by_iter.reindex(all_iterations, fill_value=0.0).mean()
            if not mean_pool_ha or mean_pool_ha <= 0:
                continue

            # Unit fix (v3.14, kept here): convert the hectare pool to a
            # pixel count before dividing, so it matches
            # mean_n_transitioned's units.
            mean_pool_px = mean_pool_ha / px_area_ha
            yearly_rates.append(mean_n_transitioned / mean_pool_px)

        simulated_rate = float(np.mean(yearly_rates)) if yearly_rates else np.nan
        n_years_used = len(yearly_rates)

        observed_rate = observed_rates.get(group, np.nan)
        ratio = (
            observed_rate / simulated_rate
            if simulated_rate and not np.isnan(simulated_rate) and simulated_rate > 0
            else np.nan
        )

        rows.append({
            "group":          group,
            "observed_rate":  observed_rate,
            "simulated_rate": simulated_rate,
            "ratio":          ratio,
            "n_years_used":   n_years_used,
        })

    return pd.DataFrame(rows).sort_values("group").reset_index(drop=True)


# ─────────────────────────────────────────────────────────────────────────────
# Shared: apply a per-group scale factor to whichever file actually governs
# that group's sampled multiplier (Uniform -> TransitionMultipliers.csv
# min/max; named -> Distributions.csv Value column)
# ─────────────────────────────────────────────────────────────────────────────

def _apply_group_scales(
    scale_by_group:           dict[str, float],
    transition_mult_csv_path: str | Path,
    distributions_csv_path:   str | Path | None,
    bounds:                   tuple[float, float],
) -> dict[str, pd.DataFrame]:
    """
    Apply scale_by_group[group] to each group's governing file.

    Returns dict with keys "transition_multipliers" (always present) and
    "distributions" (present only if distributions_csv_path was supplied
    and exists).
    """
    mult_df = pd.read_csv(transition_mult_csv_path)
    if "TransitionGroupId" not in mult_df.columns:
        raise ValueError(
            f"'{transition_mult_csv_path}' has no TransitionGroupId column -- "
            f"got columns: {list(mult_df.columns)}"
        )

    lo, hi = bounds
    dist_df = None
    if distributions_csv_path is not None and Path(distributions_csv_path).exists():
        dist_df = pd.read_csv(distributions_csv_path)

    n_uniform_corrected = 0
    n_named_corrected = 0
    n_skipped_no_distfile = 0

    for idx, row in mult_df.iterrows():
        group = _strip_type_suffix(str(row.get("TransitionGroupId", "")))
        scale = scale_by_group.get(group)
        if scale is None:
            continue

        dist_type = str(row.get("DistributionType", "")).strip()
        is_uniform = dist_type.lower() in _LITERAL_DISTRIBUTIONS

        if is_uniform:
            for col in ("DistributionMin", "DistributionMax", "Amount"):
                if col in mult_df.columns and pd.notna(row.get(col)):
                    new_val = float(row[col]) * scale
                    new_val = min(max(new_val, lo), hi)
                    mult_df.at[idx, col] = new_val
            n_uniform_corrected += 1
        else:
            # Named distribution -- DistributionMin/Max are inert at
            # sample time (see core.multipliers._sample); the real
            # correction target is Distributions.csv's Value column for
            # this DistributionTypeId.
            if dist_df is None:
                print(f"  [Warning] Group '{group}' uses named distribution "
                      f"'{dist_type}', but no Distributions.csv was supplied "
                      f"-- scaling DistributionMin/Max would be a no-op "
                      f"(engine ignores them for non-'Uniform' rows), so "
                      f"this group was left UNCORRECTED. Pass "
                      f"distributions_csv_path to correct it.")
                n_skipped_no_distfile += 1
                continue

            mask = dist_df["DistributionTypeId"].astype(str).str.strip() == dist_type
            if not mask.any():
                print(f"  [Warning] DistributionTypeId '{dist_type}' (group "
                      f"'{group}') not found in Distributions.csv -- skipped.")
                continue

            new_vals = dist_df.loc[mask, "Value"].astype(float) * scale
            new_vals = new_vals.clip(lower=lo, upper=hi)
            dist_df.loc[mask, "Value"] = new_vals
            n_named_corrected += 1

    print(f"  correct_multipliers: {n_uniform_corrected} 'Uniform' row(s) "
          f"rescaled in TransitionMultipliers.csv, {n_named_corrected} named "
          f"distribution(s) rescaled in Distributions.csv"
          + (f", {n_skipped_no_distfile} group(s) left uncorrected "
             f"(no Distributions.csv supplied)" if n_skipped_no_distfile else "")
          + f"  (bounds={bounds})")

    result = {"transition_multipliers": mult_df}
    if dist_df is not None:
        result["distributions"] = dist_df
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Multiplier correction
# ─────────────────────────────────────────────────────────────────────────────

def correct_multipliers(
    rate_ratios:              pd.DataFrame,
    transition_mult_csv_path: str | Path,
    method:                   str = "scaling",
    bounds:                   tuple[float, float] = (0.01, 100.0),
    distributions_csv_path:   str | Path | None = None,
    # -- method="optimize" only --
    manifest_path:            str | Path | None = None,
    ts=None,
    target_groups:            list[str] | None = None,
    n_iterations_per_trial:   int = 5,
    max_reruns:               int = 8,
) -> dict[str, pd.DataFrame]:
    """
    Correct Transition Multipliers for flagged pathways.

    Parameters
    ----------
    rate_ratios : output of compute_pathway_rate_ratios()
                  (group, observed_rate, simulated_rate, ratio). Used
                  directly as the scale factor for method="scaling";
                  used only to pick which groups to search over for
                  method="optimize" (the ratio itself is just the
                  optimizer's starting guess there).
    transition_mult_csv_path : path to the existing TransitionMultipliers.csv.
                  Read and returned in its ORIGINAL column schema -- rows
                  for unaffected groups are preserved untouched.
    method      : "scaling" (default) or "optimize"
    bounds      : (min, max) clamp on the scale factor applied to
                  DistributionMin/Max (Uniform groups) or Distributions.csv
                  Value entries (named-distribution groups). Default is a
                  wide, PERMISSIVE safety valve, not a validated "safe"
                  range for your project -- it exists so the function
                  can't emit negative or runaway values, not because
                  those bounds are known to keep transition dynamics
                  realistic. Check your own TransitionMultipliers.csv's
                  typical range and tighten this per-project.
    distributions_csv_path : path to Distributions.csv, REQUIRED to
                  actually correct any group whose DistributionType is a
                  named reference rather than literal "Uniform" (see
                  module docstring -- DistributionMin/Max are inert for
                  those groups). If omitted, such groups are flagged and
                  left uncorrected rather than silently doing nothing.

    method="optimize" only
    -----------------------
    manifest_path : calibrated RunManifest.txt (same one hindcast_run()
                  used) -- required, since each trial needs to re-run the
                  engine.
    ts            : LULCTimeSeries covering the hindcast window --
                  required, same reason.
    target_groups : which groups to search over; defaults to every group
                  in rate_ratios with a non-NaN ratio.
    n_iterations_per_trial : engine iterations per trial re-run (default
                  5 -- cheaper than hindcast_run()'s own default of 20,
                  since this runs up to max_reruns times PER group).
    max_reruns    : max trial re-runs per group (default 8). This is the
                  binding budget constraint -- the bounded search's
                  internal maxiter is capped to this value.

    Returns
    -------
    dict with key "transition_multipliers" (always) and "distributions"
    (only if distributions_csv_path was supplied and exists). Neither is
    written to disk -- caller decides.
    """
    if method not in ("scaling", "optimize"):
        raise ValueError(f"Unknown method '{method}'. Use 'scaling' or 'optimize'.")

    if method == "scaling":
        scale_by_group = {
            row["group"]: row["ratio"]
            for _, row in rate_ratios.iterrows()
            if pd.notna(row["ratio"])
        }
        return _apply_group_scales(
            scale_by_group, transition_mult_csv_path, distributions_csv_path, bounds
        )

    # ── method == "optimize" ──────────────────────────────────────────────
    if manifest_path is None or ts is None:
        raise ValueError(
            "method='optimize' requires manifest_path and ts (each trial "
            "needs to re-run the engine over the hindcast window)."
        )

    from scipy.optimize import minimize_scalar
    from .hindcast import hindcast_run
    import tempfile

    groups = target_groups or [
        g for g in rate_ratios.loc[pd.notna(rate_ratios["ratio"]), "group"]
    ]

    scale_by_group: dict[str, float] = {}

    for group in groups:
        starting_ratio = float(
            rate_ratios.loc[rate_ratios["group"] == group, "ratio"].iloc[0]
        )
        n_evals = 0

        def objective(scale: float) -> float:
            nonlocal n_evals
            n_evals += 1
            with tempfile.TemporaryDirectory() as tmp:
                tmp = Path(tmp)
                trial = _apply_group_scales(
                    {group: scale}, transition_mult_csv_path,
                    distributions_csv_path, bounds,
                )
                trial_mult_path = tmp / "TransitionMultipliers.csv"
                trial["transition_multipliers"].to_csv(trial_mult_path, index=False)

                trial_dist_path = None
                if "distributions" in trial:
                    trial_dist_path = tmp / "Distributions.csv"
                    trial["distributions"].to_csv(trial_dist_path, index=False)

                result = hindcast_run(
                    manifest_path=manifest_path, ts=ts,
                    n_iterations=n_iterations_per_trial,
                    out_dir=tmp / "trial_run",
                    transition_mult_csv_override=trial_mult_path,
                    distributions_csv_override=trial_dist_path,
                    lightweight=True,
                )
                ec = result.extent_comparison
                final_year = ec["year"].max()
                sse = (ec.loc[ec["year"] == final_year, "abs_diff"] ** 2).sum()
                return float(sse)

        opt_result = minimize_scalar(
            objective, bounds=bounds, method="bounded",
            options={"maxiter": max_reruns, "xatol": 1e-2},
        )
        print(f"  [optimize] group='{group}': best_scale={opt_result.x:.4f} "
              f"(started from ratio={starting_ratio:.4f}, "
              f"{n_evals} re-run(s), converged={opt_result.success})")
        scale_by_group[group] = float(opt_result.x)

    return _apply_group_scales(
        scale_by_group, transition_mult_csv_path, distributions_csv_path, bounds
    )
