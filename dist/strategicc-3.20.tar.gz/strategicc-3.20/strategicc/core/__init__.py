from .transitions import build_transition_index, TransitionRecord
from .adjacency   import compute_neighbor_fractions
from .spatial     import load_spatial_multipliers, resolve_spatial_multipliers_per_timestep
from .multipliers import sample_transition_multipliers, describe_multiplier_rules
from .age         import (
    build_initial_age_from_raster,
    build_initial_age_from_rules,
    update_age,
    age_gate_mask,
    save_age_tif,
)
from .patches import (
    sample_patch_size_ha,
    grow_patch,
    grow_patches_for_group,
)
from .targets import (
    resolve_targets_per_timestep,
    scale_probability_to_target,
    target_to_patch_budget,
)

__all__ = [
    "build_transition_index",
    "TransitionRecord",
    "compute_neighbor_fractions",
    "load_spatial_multipliers",
    "resolve_spatial_multipliers_per_timestep",
    "sample_transition_multipliers",
    "describe_multiplier_rules",
    "build_initial_age_from_raster",
    "build_initial_age_from_rules",
    "update_age",
    "age_gate_mask",
    "save_age_tif",
    "sample_patch_size_ha",
    "grow_patch",
    "grow_patches_for_group",
    "resolve_targets_per_timestep",
    "scale_probability_to_target",
    "target_to_patch_budget",
]
