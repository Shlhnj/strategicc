"""
stsm/config.py
--------------
Runtime configuration: file paths, feature toggles, and tuning constants.
Edit this file to point at your data and adjust model behaviour.
"""

from pathlib import Path

# ── Input paths ───────────────────────────────────────────────────────────────
LULC_PATH             = Path("2022.tif")
MULT_DIR              = Path("spatmult_uploads/")
OUT_DIR               = Path("stsm_output/")

# ST-Sim–format CSV inputs
STATE_CLASSES_CSV        = Path("inputs/StateClasses.csv")
TRANSITIONS_CSV          = Path("inputs/Transitions.csv")
SPATIAL_MULT_CSV         = Path("inputs/TransitionSpatialMultipliers.csv")
TRANSITION_MULT_CSV      = Path("inputs/TransitionMultipliers.csv")   # v1.1

# ── Simulation settings ───────────────────────────────────────────────────────
START_YEAR   = 2022
N_TIMESTEPS  = 10
N_ITERATIONS = 10    # v1.1 — number of Monte Carlo runs
RNG_SEED     = 42    # base seed; each iteration gets seed + iter_index

# ── Feature toggles ───────────────────────────────────────────────────────────
USE_ADJACENCY        = True   # weight transitions by neighbour class fractions
USE_SPATIAL_MULT     = True   # apply spatial multiplier rasters
USE_TRANS_MULTIPLIER = True   # v1.1 — apply stochastic transition multipliers

# ── Adjacency tuning ──────────────────────────────────────────────────────────
ADJACENCY_STRENGTH = 4.0
# Groups that MUST touch an existing neighbour of the target class to fire.
# All others get a baseline of 1.0 + boost (can fire anywhere, boosted near target).
STRICT_EXPANSION_GROUPS: set[str] = {
    "Agriculture_expansion",
    "Aquaculture_expansion",
    "Mangrove_recruitment",
    "Sedimentation",
    "Urbanization",
}

# ── Spatial multiplier tuning ─────────────────────────────────────────────────
# Applied AFTER the 0-1 normalisation.  Higher = transitions more tightly
# clustered near the feature.  Tune per-group as needed.
SHARPENING_POWER: dict[str, int] = {
    "Agriculture_expansion": 6,
    "Aquaculture_expansion": 6,
    "Inundation":            8,
    "Mangrove_recruitment":  4,
    "Sedimentation":         4,
    "Urbanization":          6,
}
DEFAULT_SHARPENING_POWER = 4
