"""
stsm — State-and-Transition Simulation Model  v1.0
"""

from .engine import STSMEngine

__version__ = "1.0.0"
__all__ = ["STSMEngine"]
