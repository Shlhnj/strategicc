"""
stsm/run.py  —  v1.1
---------------------
Entry point.

    python -m stsm.run

or:

    from stsm.run import main
    main()
"""

from pathlib import Path
from stsm import STSMEngine
from stsm import outputs


def main() -> None:
    # ── 1. Build & load ───────────────────────────────────────────────────────
    engine = STSMEngine.from_config()
    engine.load()
    engine.diagnostic()

    # ── 2. Run all iterations (writes per-iter TIFs + CSVs to disk) ──────────
    engine.run()

    # ── 3. Aggregate across iterations ───────────────────────────────────────
    summary_dir = engine.out_dir / "summary"
    print("\n[7] Building summary tables...")
    area_df, trans_df = outputs.build_summary_tables(
        engine.iter_dirs, summary_dir
    )

    # ── 4. Envelope plots ─────────────────────────────────────────────────────
    print("\n[8] Generating summary plots...")
    outputs.plot_area_envelope(area_df, engine.classes, summary_dir)
    outputs.plot_transition_envelope(trans_df, summary_dir)

    # ── 5. Single-iteration diagnostic plots (iter 1) ────────────────────────
    # Re-run iter 1 in memory just for map visualisation
    print("\n[9] Generating diagnostic maps (iteration 1)...")
    from stsm.core.transitions import TransitionRecord
    diag_dir = summary_dir / "diagnostic_iter1"
    diag_dir.mkdir(parents=True, exist_ok=True)

    # Read saved iter_001 TIFs back for plotting
    from stsm.io.raster import read_lulc
    maps_iter1 = []
    for t in range(engine.n_timesteps + 1):
        tif = engine.iter_dirs[0] / f"lulc_{engine.start_year + t}.tif"
        if tif.exists():
            arr, *_ = read_lulc(tif)
            maps_iter1.append(arr)

    if maps_iter1:
        outputs.plot_lulc_maps(
            maps_iter1, engine.classes, engine.start_year, diag_dir
        )

    print("\n✓ Done.")
    print(f"  Outputs in: {engine.out_dir.resolve()}")


if __name__ == "__main__":
    main()
